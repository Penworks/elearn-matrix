SuperGeekery Tag Stripper version 1.0.2

Installation:

To install the SuperGeekery Tag Stripper, put the folder 'tagstripper' into your 'system/expressionengine/third_party/' folder.

If you have comments about this add on, please post them to its home page:

http://supergeekery.com/geekblog/comments/expression_engine_2_plugin_supergeekery_tag_stripper_version_1.0

Thanks,

John
